COMOREA — dossier du site

Pour lancer le site :
1. Ouvre le fichier index.html avec Chrome, Edge ou un autre navigateur.
2. Le site fonctionne directement en local pour les fonctions incluses dans le fichier.

Dossier principal :
- index.html : page complète du site COMOREA
